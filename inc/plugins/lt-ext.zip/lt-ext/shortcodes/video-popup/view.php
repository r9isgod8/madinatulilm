<?php if ( ! defined( 'ABSPATH' ) ) die( 'Forbidden' );
/**
 * Shortcode
 */

$args = get_query_var('like_sc_video_popup');

if ( !empty($atts['header_type']) ) $tag = 'h'.$atts['header_type']; else $tag = 'h4';

$class = '';
if ( !empty($atts['class']) ) $class .= ' '. esc_attr($atts['class']);
if ( !empty($atts['id']) ) $id = ' id="'. esc_attr($atts['id']). '"'; else $id = '';

$class .= ' style-'.$atts['style'];

$image = ltx_get_attachment_img_url( $atts['image'] );
$image2 = ltx_get_attachment_img_url( $atts['image2'] );
$atts['header'] = str_replace(array('{{', '}}'), array('<span>', '</span>'), $atts['header']);

echo '<a href="'.esc_url($atts['href']).'" class="swipebox ltx-video-popup ' . esc_attr( $class ) .'" '.$id.'>';

	echo '<span class="image">
			<img src="' . esc_url($image[0]) . '" class="image" alt="'.esc_attr($atts['header']).'">
			<span class="ltx-play-wrap"></span>
		</span>';
		
echo '</a>';


