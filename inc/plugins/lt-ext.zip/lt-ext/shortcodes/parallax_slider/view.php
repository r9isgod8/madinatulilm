<?php if ( ! defined( 'ABSPATH' ) ) die( 'Forbidden' );
/**
 * Zoom Slider Shortcode
 */

$args = get_query_var('like_sc_parallax_slider');

$class = '';
if ( !empty($args['class']) ) $class .= ' '. esc_attr($args['class']);
if ( !empty($args['id']) ) $id = ' id="'. esc_attr($args['id']). '"'; else $id = '';

$image1 = ltx_get_attachment_img_url($atts['image1']);


?> 
<div class="ltx-parallax-slider-wrapper ltx-parallax-slider">
	<?php if ( !empty($image1) ): ?>
	<div data-depth="0.3" data-direction="horizontal" class="ltx-layer ltx-layer-2 ltx-floating-image">
		<img class="ltx-floating-image" alt="bg" src="<?php echo esc_url($image1[0]); ?>" >
	</div>		
	<?php endif; ?>
</div>
